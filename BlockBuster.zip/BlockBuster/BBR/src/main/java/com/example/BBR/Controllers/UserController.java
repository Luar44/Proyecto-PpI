package com.example.BBR.Controllers;

import com.example.BBR.Models.UserModel;
import com.example.BBR.Services.UserService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    //get
    @GetMapping()
    public ArrayList<UserModel> findAllUsers(){
        return userService.findAllUsers();
    }
    //post
    @PostMapping()
    public UserModel saveUser(@RequestBody UserModel user){
        return userService.saveUser(user);
    }
    //put
    @PutMapping()
    public UserModel updateUser(@RequestBody UserModel user){
        return userService.saveUser(user);
    }
    //buscar por nombre
    @GetMapping(path ="/find-by-name")//localhost:8080/student/find-by-name?
    public ArrayList<UserModel> findByName(@RequestParam("name")String name){return userService.findByName(name);}
    //buscar por telefono
    @GetMapping(path ="/find-by-cellphone")//localhost:8080/student/find-by-cellphone?
    public ArrayList<UserModel> findByCellphone(@RequestParam("cellphone")Long cellphone){return userService.findByCellphone(cellphone);}
    //borrar


}
