package com.example.BBR.Services;

import com.example.BBR.Models.UserModel;
import com.example.BBR.Repositories.UserRepository;
import jakarta.persistence.Id;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {
    private Map<String, String> peliculasMap = new HashMap<>();

    @Autowired
    UserRepository userRepository;
    //inicializo y doy valores a mi mapa
    public UserService(){
        peliculasMap.put("T01CF","Titanic (20th Century Fox)");
        peliculasMap.put("J02UP","Jurassic Park (Universal Pictures)");
        peliculasMap.put("S03SP","Spider Man (Sony Pictures)");
        peliculasMap.put("I04WB","Inception (Warner Bros)");
        peliculasMap.put("L05NL","The Lord Of The Rings: The Fellowship Of The Ring (New Line Cinema)");
        peliculasMap.put("S06DW","Shrek 2 (DreamWorks)");
        peliculasMap.put("A07CF","Avatar (20th Century Fox)");
        peliculasMap.put("I08WB","It (Warner Bros)");
        peliculasMap.put("P09BA","Pulp Fiction (A Brand Apart)");
        peliculasMap.put("T10VX","The Texas Chain Saw Massacre (Vortex)");

    }
    //obtener a todos los usuarios regisrados
    public ArrayList<UserModel> findAllUsers(){
        return (ArrayList<UserModel>) userRepository.findAll();
    }
    //guardar a un nuevo cliente

    public UserModel saveUser(UserModel user){
        String code = user.getCode();
        String codeValue = peliculasMap.get(code);
        user.setCode(codeValue);
        return userRepository.save(user);
    }
    //buscar por nombre
    public ArrayList<UserModel> findByName(String name){return userRepository.findByName(name);}
    //buscar por telefono
    public ArrayList<UserModel> findByCellphone(Long cellphone){return userRepository.findByCellphone(cellphone);}


}
