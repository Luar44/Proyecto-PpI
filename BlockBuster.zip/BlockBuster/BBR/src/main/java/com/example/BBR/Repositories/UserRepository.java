package com.example.BBR.Repositories;

import com.example.BBR.Models.UserModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.yaml.snakeyaml.events.Event;

import java.util.ArrayList;

@Repository
public interface UserRepository extends CrudRepository<UserModel,Long> {
    //buscar por nombre
    public abstract ArrayList<UserModel> findByName(String name);
    //buscar por telefono
    public abstract ArrayList<UserModel> findByCellphone(Long cellphone);


}
