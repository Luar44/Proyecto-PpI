package com.example.blockbuster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockBusterApplication {

    public static void main(String[] args) {
        SpringApplication.run(BlockBusterApplication.class, args);
    }

}
