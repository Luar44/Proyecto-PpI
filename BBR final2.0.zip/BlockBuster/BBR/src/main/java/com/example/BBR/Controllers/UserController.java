package com.example.BBR.Controllers;

import com.example.BBR.Models.UserModel;
import com.example.BBR.Repositories.UserRepository;
import com.example.BBR.Services.UserService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {
    @Autowired
    UserService userService;

    //get
    @GetMapping()
    public ArrayList<UserModel> findAllUsers(){
        return userService.findAllUsers();
    }
    //post
    @PostMapping()
    public UserModel saveUser(@RequestBody UserModel user){
        return userService.saveUser(user);
    }
    //put
    @PutMapping()
    public UserModel updateUser(@RequestBody UserModel user){
        return userService.saveUser(user);
    }
    //buscar por codigo
    @GetMapping(path ="/find-by-code")//localhost:8080/student/find-by-code?
    public ArrayList<UserModel> findByCode(@RequestParam("code")Integer code){return userService.findByCode(code);}
    //eliminar por codigo
    @DeleteMapping(path="{code}")
    public String deleteByCode(@PathVariable("code") Integer code){
        int respuesta = this.userService.deleteByCode(code);
        if(respuesta==1){return "Se eliminoooo";}
        else{return "no se elimino";}
    }
}
