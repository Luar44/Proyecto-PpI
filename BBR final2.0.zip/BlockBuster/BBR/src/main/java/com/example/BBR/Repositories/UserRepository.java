package com.example.BBR.Repositories;

import com.example.BBR.Models.UserModel;
import org.aspectj.apache.bcel.classfile.LineNumberTable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.yaml.snakeyaml.events.Event;

import java.util.ArrayList;

    @Repository
    public interface UserRepository extends CrudRepository<UserModel,Long> {
    //buscar por codigo
    public abstract ArrayList<UserModel> findByCode(Integer code);
    //eliminar por codigo
    public abstract Integer deleteByCode(Integer code);
}
