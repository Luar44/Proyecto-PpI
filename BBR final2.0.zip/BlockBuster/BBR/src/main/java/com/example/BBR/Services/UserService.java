package com.example.BBR.Services;

import com.example.BBR.Models.UserModel;
import com.example.BBR.Repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;


@Service
@Transactional
public class UserService {

    @Autowired
    UserRepository userRepository;
    //inicializo y doy valores a mi mapa

    //obtener a todos los usuarios regisrados
    public ArrayList<UserModel> findAllUsers(){
        return (ArrayList<UserModel>) userRepository.findAll();
    }
    //guardar a un nuevo cliente

    public UserModel saveUser(UserModel user){
        return userRepository.save(user);
    }
    //buscar por codigo
    public ArrayList<UserModel> findByCode(Integer code){return userRepository.findByCode(code);}
    //borrar por codigo
    public int deleteByCode(Integer code){return userRepository.deleteByCode(code);}

}
